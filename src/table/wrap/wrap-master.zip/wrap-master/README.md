# wrap
Go library for wrapping long strings.
