package hresult // import "rs3.io/go/mserr/hresult"

type HResult uint32
