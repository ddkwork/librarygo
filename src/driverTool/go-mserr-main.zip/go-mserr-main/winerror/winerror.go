package winerror // import "rs3.io/go/mserr/winerror"

type Win32Error uint32
