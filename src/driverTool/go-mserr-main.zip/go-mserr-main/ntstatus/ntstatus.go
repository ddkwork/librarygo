package ntstatus // import "rs3.io/go/mserr/ntstatus"

type NTStatus uint32
