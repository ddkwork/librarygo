package mserr // import "rs3.io/go/mserr"
//go:generate go run ./ms-erref-generate.go
